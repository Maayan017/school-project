package com.example.idk;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.idk.view.GameActivity;

public class ResultActivity extends AppCompatActivity {

    private TextView correctAnswersText, totalQuestionsText, scoreResultText;
    private Button playAgainButton, homeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        correctAnswersText = findViewById(R.id.correctAnswersText);
        totalQuestionsText = findViewById(R.id.totalQuestionsText);
        scoreResultText = findViewById(R.id.scoreResultText);
        playAgainButton = findViewById(R.id.playAgainButton);
        homeButton = findViewById(R.id.homeButton);

        // קבלת הניקוד מה-Intent
        int finalScore = getIntent().getIntExtra("finalScore", 0);

        // מכיוון שהמשחק מונה 10 שאלות, ניקח את זה כחישוב
        int totalQuestions = 10;
        int correctAnswers = finalScore; // ניקוד הוא מספר התשובות הנכונות

        // עדכון הטקסטים בהתאם לניקוד
        correctAnswersText.setText("תשובות נכונות: " + correctAnswers);
        totalQuestionsText.setText("סה״כ שאלות: " + totalQuestions);
        scoreResultText.setText("ניקוד סופי: " + finalScore * 10);  // לדוגמה ניקוד פי 10

        // לחצן שחק שוב - מעביר חזרה ל-GameActivity
        playAgainButton.setOnClickListener(v -> {
            Intent intent = new Intent(ResultActivity.this, GameActivity.class);
            startActivity(intent);
            finish();
        });

        // לחצן חזרה לתפריט - מעביר ל-HomeScreenActivity
        homeButton.setOnClickListener(v -> {
            Intent intent = new Intent(ResultActivity.this, HomeScreenActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
