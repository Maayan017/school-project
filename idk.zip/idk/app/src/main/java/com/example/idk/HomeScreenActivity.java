package com.example.idk;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.idk.view.GameActivity;

public class HomeScreenActivity extends AppCompatActivity {

    CardView button1Card, button2Card, button3Card;
    Button startGameButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homescreen);

        button1Card = findViewById(R.id.button1Card);
        button2Card = findViewById(R.id.button2Card);
        button3Card = findViewById(R.id.button3Card);
        startGameButton = findViewById(R.id.startGameButton);

        // מעבר ל- activity_profile.xml
        button1Card.setOnClickListener(v -> {
            Intent intent = new Intent(HomeScreenActivity.this, ProfileActivity.class);
            startActivity(intent);
        });

        // מעבר ל- activity_settings.xml
        button2Card.setOnClickListener(v -> {
            Intent intent = new Intent(HomeScreenActivity.this, SettingsActivity.class);
            startActivity(intent);
        });

        // מעבר ל- activity_help.xml
        button3Card.setOnClickListener(v -> {
            Intent intent = new Intent(HomeScreenActivity.this, HelpActivity.class);
            startActivity(intent);
        });

        // מעבר ל- activity_game.xml
        startGameButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeScreenActivity.this, GameActivity.class);
            startActivity(intent);
        });
    }
}
