package com.example.idk.view;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.idk.R;
import com.example.idk.controller.GameController;

public class GameActivity extends AppCompatActivity {

    private TextView questionText, scoreText, timerText;
    private EditText answerEditText;
    private Button submitAnswerButton;
    private ImageButton muteButton;
    private ImageView characterImage;

    private CountDownTimer timer;
    private boolean isMuted = false;

    private GameController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        controller = new GameController(this);

        questionText = findViewById(R.id.questionText);
        scoreText = findViewById(R.id.scoreText);
        timerText = findViewById(R.id.timerText);
        muteButton = findViewById(R.id.muteButton);
        characterImage = findViewById(R.id.characterImage);
        answerEditText = findViewById(R.id.answerEditText);
        submitAnswerButton = findViewById(R.id.submitAnswerButton);

        loadNewQuestion();
        startTimer();

        muteButton.setOnClickListener(v -> toggleMute());
        submitAnswerButton.setOnClickListener(v -> submitAnswer());
    }

    private void loadNewQuestion() {
        String question = controller.newQuestion();
        questionText.setText(question);
        answerEditText.setText("");
    }

    private void submitAnswer() {
        controller.submitAnswer(answerEditText.getText().toString());
        scoreText.setText("⭐ ניקוד: " + controller.getScore());
        loadNewQuestion();
    }

    private void toggleMute() {
        isMuted = !isMuted;
        int icon = isMuted
                ? android.R.drawable.ic_lock_silent_mode
                : android.R.drawable.ic_lock_silent_mode_off;
        muteButton.setImageResource(icon);
    }

    private void startTimer() {
        timer = new CountDownTimer(30000, 1000) {
            public void onTick(long millisUntilFinished) {
                timerText.setText("⌛ " + (millisUntilFinished / 1000));
            }

            public void onFinish() {
                controller.submitAnswer("0"); // סוגר משחק גם אם הזמן נגמר
            }
        }.start();
    }

    @Override
    protected void onDestroy() {
        if (timer != null) timer.cancel();
        super.onDestroy();
    }
}
