package com.example.idk;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private ImageView profileImage;
    private EditText editUsername;
    private TextView userLevelText;
    private Button saveSettingsButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        profileImage = findViewById(R.id.profileImage);
        editUsername = findViewById(R.id.editUsername);
        userLevelText = findViewById(R.id.userLevelText);
        saveSettingsButton = findViewById(R.id.saveSettingsButton);

        // ניתן כאן לטעון תמונת פרופיל ממשית, לדוגמה:
        // profileImage.setImageResource(R.drawable.ic_profile_placeholder);

        // ניתן לטעון את שם המשתמש והרמה ממקור נתונים (לדוגמה SharedPreferences)
        editUsername.setText("שם משתמש לדוגמה");
        userLevelText.setText("מתחיל"); // טקסט בלבד, לא ניתן לשנות

        saveSettingsButton.setOnClickListener(v -> {
            String newUsername = editUsername.getText().toString();
            // כאן אפשר לשמור את השם החדש (למשל SharedPreferences)

            Toast.makeText(SettingsActivity.this, "השינויים נשמרו", Toast.LENGTH_SHORT).show();
        });
    }
}
