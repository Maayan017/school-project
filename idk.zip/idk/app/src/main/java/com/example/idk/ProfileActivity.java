package com.example.idk;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProfileActivity extends AppCompatActivity {

    ImageView profileImage;
    TextView usernameText, emailText;
    Button editProfileButton, logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);  // מחבר לקובץ ה-XML של מסך הפרופיל

        // חיבור רכיבים מה-XML
        profileImage = findViewById(R.id.profileImage);
        usernameText = findViewById(R.id.usernameText);
        emailText = findViewById(R.id.emailText);
        editProfileButton = findViewById(R.id.editProfileButton);
        logoutButton = findViewById(R.id.logoutButton);

        // ערכים לדוגמה
        usernameText.setText("רוני כהן");
        emailText.setText("roni@example.com");

        // לחיצה על עריכת פרופיל
        editProfileButton.setOnClickListener(v -> {
            Toast.makeText(this, "עריכת פרופיל לא זמינה עדיין", Toast.LENGTH_SHORT).show();
        });

        // לחיצה על התנתקות
        logoutButton.setOnClickListener(v -> {
            Toast.makeText(this, "התנתקת מהמערכת", Toast.LENGTH_SHORT).show();
            finish(); // סגירת המסך, חזרה למסך הקודם (למשל login)
        });
    }
}
