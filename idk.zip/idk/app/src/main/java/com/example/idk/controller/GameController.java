package com.example.idk.controller;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.example.idk.ResultActivity;
import com.example.idk.model.GameModel;

public class GameController {
    private final GameModel model;
    private final Context context;

    public GameController(Context context) {
        this.context = context;
        this.model = new GameModel();
    }

    public String newQuestion() {
        return model.generateQuestion();
    }

    public void submitAnswer(String userAnswer) {
        try {
            int answer = Integer.parseInt(userAnswer);
            boolean correct = model.checkAnswer(answer);

            if (correct) {
                Toast.makeText(context, "תשובה נכונה!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context,
                        "תשובה שגויה! התשובה הנכונה היא " + model.getCorrectAnswer(),
                        Toast.LENGTH_SHORT).show();
            }

            if (model.isGameOver()) {
                goToResults();
            }

        } catch (NumberFormatException e) {
            Toast.makeText(context, "הכנס מספר תקין", Toast.LENGTH_SHORT).show();
        }
    }

    public int getScore() {
        return model.getScore();
    }

    private void goToResults() {
        Intent intent = new Intent(context, ResultActivity.class);
        intent.putExtra("finalScore", model.getScore());
        context.startActivity(intent);
    }
}
