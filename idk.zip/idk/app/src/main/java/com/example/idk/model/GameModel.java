package com.example.idk.model;

import java.util.Random;

public class GameModel {
    private int correctAnswer;
    private int score = 0;
    private int gameCount = 0;

    private final Random rand = new Random();

    public String generateQuestion() {
        int a = rand.nextInt(10) + 1;
        int b = rand.nextInt(10) + 1;
        correctAnswer = a + b;
        return "כמה זה: " + a + " + " + b + " ?";
    }

    public boolean checkAnswer(int userAnswer) {
        gameCount++;
        if (userAnswer == correctAnswer) {
            score++;
            return true;
        }
        return false;
    }

    public int getCorrectAnswer() {
        return correctAnswer;
    }

    public int getScore() {
        return score;
    }

    public int getGameCount() {
        return gameCount;
    }

    public boolean isGameOver() {
        return gameCount >= 10;
    }
}
